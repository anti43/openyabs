package org.supercsv.util;

public interface TestInterface {
String getName();

void setName(String name);
}
