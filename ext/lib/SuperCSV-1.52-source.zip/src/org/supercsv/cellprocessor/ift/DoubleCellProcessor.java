package org.supercsv.cellprocessor.ift;

public interface DoubleCellProcessor extends CellProcessor {
}
